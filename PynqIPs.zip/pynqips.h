#include "hls_stream.h"
#include "ap_fixed.h"
#include "ap_axi_sdata.h"

typedef ap_axiu<32,1,1,1> stream_type;

void mult_constant(stream_type* in_data, stream_type* out_data, ap_int<32> constant);
void add(int a, int b, int& c);
void addfloat(int a, int b, int& c);

