// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaddfloat.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAddfloat_CfgInitialize(XAddfloat *InstancePtr, XAddfloat_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAddfloat_Set_a(XAddfloat *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddfloat_WriteReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_A_DATA, Data);
}

u32 XAddfloat_Get_a(XAddfloat *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddfloat_ReadReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_A_DATA);
    return Data;
}

void XAddfloat_Set_b(XAddfloat *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddfloat_WriteReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_B_DATA, Data);
}

u32 XAddfloat_Get_b(XAddfloat *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddfloat_ReadReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_B_DATA);
    return Data;
}

u32 XAddfloat_Get_c(XAddfloat *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddfloat_ReadReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_C_DATA);
    return Data;
}

u32 XAddfloat_Get_c_vld(XAddfloat *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddfloat_ReadReg(InstancePtr->Axilites_BaseAddress, XADDFLOAT_AXILITES_ADDR_C_CTRL);
    return Data & 0x1;
}

