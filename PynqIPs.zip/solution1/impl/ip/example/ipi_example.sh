# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/home/bartek/Xilinx/Vivado/2019.1/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xc7z020-clg484-1 ../xilinx_com_hls_addfloat_1_0.zip
